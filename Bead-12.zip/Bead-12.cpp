#include<iostream>
#include<conio.h>
#include<iomanip>
#include<Windows.h>
#include<fstream>
#define rows 85
#define cols 117
#define S '-'
using namespace std;
enum COL { w, b };
void getRowColbyLeftClick(int& rpos, int& cpos)
{
	HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
	DWORD Events;
	INPUT_RECORD InputRecord;
	SetConsoleMode(hInput, ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT | ENABLE_EXTENDED_FLAGS);
	do
	{
		ReadConsoleInput(hInput, &InputRecord, 1, &Events);
		if (InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
		{
			cpos = InputRecord.Event.MouseEvent.dwMousePosition.X;
			rpos = InputRecord.Event.MouseEvent.dwMousePosition.Y;
			break;
		}
	} while (true);
}
void gotoRowCol(int rpos, int cpos)
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = cpos;
	scrn.Y = rpos;
	SetConsoleCursorPosition(hOuput, scrn);
}
void SetClr(int clr)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), clr);
}



struct pos
{
	int ri, ci;
};

struct cs
{
	string s;
	int t;
	int c;
};
bool isH(pos Sc, pos Dc)
{
	return(Sc.ri == Dc.ri);
	

}
bool isV(pos Sc, pos Dc)
{
	return(Sc.ci == Dc.ci);


}
bool isD(pos Sc, pos Dc)
{
	int dr = abs(Sc.ri - Dc.ri);
	int ds = abs(Sc.ci - Dc.ci);
	return(dr == ds);

}

void d(int r, int c, int rr, int cc)
{
	for (int i = 0; i < rr; i++)
	{
		gotoRowCol(i + r, i + c);
		cout << char(-37);
	}
}

void d2(int r, int c, int rr, int cc)
{
	int j = rr;
	for (int i = 0; j >= 0; i++)
	{
		gotoRowCol(i + r, j + c);

		cout << char(-37);
		j--;
	}
}








void box(char b, int sr, int sc, int brow, int bcol, int col, int bk)
{

	for (int r = 0; r < brow; r++)
	{
		for (int c = 0; c < bcol; c++)
		{
			if (r == 0 || c == 0 || r == brow || c == bcol) {

				SetClr(col);
				gotoRowCol(r + sr, c + sc);
				cout << char(-37);
			}
		}
	}
}

void printg(char** b, int dim)
{
	int brow = 14, bcol = 14;
	int x = dim;
	for (int r = 0; r < dim; r++)
	{

		for (int c = 0; c < dim; c++, x--)
		{
			if (r == dim - 1)
			{
				for (int i = 0; i < dim * brow; i++)
				{
					gotoRowCol(r * brow + brow, i);
					cout << char(-37);
				}
			}
			if (r == dim - 1)
			{
				for (int i = 0; i < dim * brow; i++)
				{
					gotoRowCol(i, r * brow + brow);
					cout << char(-37);
				}
			}
			if ((r + c) % 2 == 0)
			{
				
				box(b[r][c], r * brow, c * bcol, brow, bcol, 7, 15 * 8);
				d(r * brow, c * bcol, brow, bcol);
			}
			else
			{
				d2(r * brow, c * bcol, brow, bcol);
				box(b[r][c], r * brow, c * bcol, brow, bcol, 8, 15 * 9);
			}

		}
	}

	for (int r = 0; r <= dim; r++)
	{
		for (int c = 0; c <= dim; c++)
		{
			if (b[r][c] == '1')
			{
				SetClr(2);
			}
			else
			{
				SetClr(4);
			}
			gotoRowCol(r * brow, c * bcol);
			
			if (b[r][c] != '-') {
				cout << '*';
			}

		}
	}
}

void spos1(pos& p)
{

	int c1, c2;
	do {
		getRowColbyLeftClick(c2, c1);
	} while (c1 % 14 != 0 && c2 % 14 != 0);
	p.ci = c1 / 14;
	p.ri = c2 / 14;

}
void updatebrd(char**& b, pos dc, pos sc,cs &ct)
{
	
	
	b[dc.ri][dc.ci]= b[sc.ri][sc.ci];
	b[sc.ri][sc.ci] = '-';
	if (abs(sc.ri - dc.ri) == 2 &&isV(sc,dc) )
	{
		if (sc.ri > dc.ri)
		{
			b[sc.ri - 1][sc.ci] = '-';
			ct.c++;
		}
		if (sc.ri < dc.ri)
		{
			b[sc.ri + 1][sc.ci] = '-';
			ct.c++;
		}

	}
	if (abs(sc.ci - dc.ci) == 2 && isH(sc, dc))
	{
		if (sc.ci > dc.ci)
		{
			b[sc.ri][sc.ci-1] = '-';
			ct.c++;
		}
		if (sc.ci < dc.ci)
		{
			b[sc.ri][sc.ci+1] = '-';
			ct.c++;
		}

	}
	if (abs(sc.ci - dc.ci) == 2 && isD(sc, dc))
	{
		if ((sc.ci > dc.ci) && (sc.ri > dc.ri))
		{
			b[sc.ri - 1][sc.ci - 1] = '-'; ct.c++;
		}
		if ((sc.ci > dc.ci) && (sc.ri < dc.ri))
		{
			b[sc.ri + 1][sc.ci - 1] = '-'; ct.c++;
			
		}
		if ((sc.ci < dc.ci) && (sc.ri > dc.ri))
		{
			b[sc.ri - 1][sc.ci + 1] = '-'; ct.c++;
		}
		if ((sc.ci < dc.ci) && (sc.ri < dc.ri))
		{
			b[sc.ri + 1][sc.ci + 1] = '-'; ct.c++;
		}
	}


}
void turnch(int& t)
{
	t = (t + 1) % 2;

}


bool ismypice(char sym, int t)
{
	if (t == b && sym == '1')
	{
		return true;
	}
	if (t == w && sym == '0')
	{
		return true;
	}
	return false;
}
bool isvalidsc(char** b, pos sc, int dim, int t)
{
	if (sc.ci >= dim || sc.ci < 0 || sc.ri >= dim || sc.ri < 0)
	{
		return false;
	}
	return ismypice(b[sc.ri][sc.ci], t);
}
bool isvaliddc(char** b, pos dc, int dim, int t)
{
	if (dc.ci >= dim || dc.ci < 0 || dc.ri >= dim || dc.ri < 0)
	{
		return false;
	}
	return (!ismypice(b[dc.ri][dc.ci], t) || b[dc.ri][dc.ci] == '-');
}
bool islegalmove(char**& b, pos sc, pos dc, int dim, int t)
{

	if (b[dc.ri][dc.ci] != '-')
	{
		
		
		return false;
	}
	if (abs(sc.ri - dc.ri) > 2 || abs(sc.ci - dc.ci) > 2)
	{
		
		return false;
	}
	if ((sc.ci + sc.ri) % 2 != 0 && isD(sc, dc))
	{
		
		return false;
	}
	
	if ((isV(sc, dc)) && (sc.ri > dc.ri) && ((sc.ri - dc.ri) == 2) && ((ismypice(b[sc.ri - 1][sc.ci], t)||b[sc.ri-1][sc.ci]=='-')))
	{
		
		return false;
	}
	
	if (isV(sc, dc) && sc.ri < dc.ri && (dc.ri - sc.ri) == 2 && (ismypice(b[sc.ri + 1][sc.ci], t) || b[sc.ri + 1][sc.ci] == '-'))
	{
		
		return false;
	}

	if (isH(sc, dc) && sc.ci > dc.ci && (sc.ci - dc.ci) == 2 && (ismypice(b[sc.ri][sc.ci - 1], t) || b[sc.ri][sc.ci - 1] == '-'))
	{
		
		return false;
	}
	if (isH(sc, dc) && sc.ci < dc.ci && (dc.ci - sc.ci) == 2 && (ismypice(b[sc.ri][sc.ci + 1], t) || b[sc.ri][sc.ci + 1] == '-'))
	{

		return false;
	}
	if (isD(sc, dc) && sc.ci<dc.ci && sc.ri>dc.ri && abs(sc.ci - dc.ci) > 2 && (ismypice(b[sc.ri - 1][sc.ci + 1], t) || b[sc.ri - 1][sc.ci + 1] == '-'))
	{
		return false;
	}
	if (isD(sc, dc) && sc.ci < dc.ci && sc.ri < dc.ri && abs(sc.ci - dc.ci) > 2 && (ismypice(b[sc.ri + 1][sc.ci + 1], t) || b[sc.ri + 1][sc.ci + 1] == '-'))
	{
		return false;
	}
	if (isD(sc, dc) && sc.ci>dc.ci && sc.ri>dc.ri && abs(sc.ci - dc.ci) > 2 && (ismypice(b[sc.ri - 1][sc.ci - 1], t) || b[sc.ri - 1][sc.ci - 1] == '-'))
	{
		return false;
	}
	if (isD(sc, dc) && sc.ci>dc.ci && sc.ri<dc.ri && abs(sc.ci - dc.ci) > 2 && (ismypice(b[sc.ri + 1][sc.ci - 1], t) || b[sc.ri + 1][sc.ci - 1] == '-'))
	{
		return false;
	}
	
	return true;
}

void bead()
{
	srand(time(0));
	cs count[2];
	pos sc, dc; int t = w; 
	cout << "Player 1 name:";
	cin >> count[0].s;
	cout << "\nPlayer 2 name:";
	cin >> count[1].s;
	system("cls");
	
	count[0].c = 0;
	count[1].c = 0;
	count[0].t = 0;
	count[1].t = 1;
	t = rand() % 2;
	ifstream in("Text.txt");
	char** b = new char* [5];
	for (int i = 0; i < 5; i++)
	{
		b[i] = new char[5];
		for (int j = 0; j < 5; j++)
		{

			in >> b[i][j];
		}
	}
	
	printg(b, 4);
	while (true)
	{
		cout << "\nPlayer " << count[t].s << "'s turn!\n";
		do {
			do {
				do {
					cout << "\nSelection:\n";
					spos1(sc);
				} while (!isvalidsc(b, sc, 5, t));
				cout << "\nDestination:\n";
				spos1(dc);
			} while (!isvaliddc(b, dc, 5, t));
		} while (!islegalmove(b, sc, dc, 5, t));
		int x = count[t].c;
		updatebrd(b, dc, sc, count[t]);
		
		
			
	
		system("cls");
		printg(b, 4);
		cout << "\nScore player 1:" << count[0].c << "      Score player 2:" << count[1].c << endl;
		
		if (count[t].c > x)
		{
			turnch(t);
		}
		if (count[t].c == 12)
		{
			cout << "\n"<< count[t].s << " is winner!";
			break;
		}
		
		turnch(t);
	}

	

}
int main()
{
	bead();
}


